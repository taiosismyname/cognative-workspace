import { and, desc, eq, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  conversationMessages,
  conversationOrigins,
  conversations,
  councilContextItems,
  councilContextManifests,
  councilResults,
  councilRuns,
  historyImports,
  memories,
  messageOrigins,
  modelRegistry,
  modelStateArtifactSources,
  modelStateArtifacts,
  modelStateSnapshots,
  providerConnections,
  reconstructionRuns,
  users,
  type InsertUser,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); } catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  }
  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role !== undefined || user.openId === ENV.ownerOpenId) { values.role = user.role ?? "admin"; updateSet.role = values.role; }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listModels(userId: number) { const db = await getDb(); return db ? db.select().from(modelRegistry).where(eq(modelRegistry.userId, userId)).orderBy(desc(modelRegistry.updatedAt)) : []; }
export async function listConversations(userId: number) { const db = await getDb(); return db ? db.select().from(conversations).where(eq(conversations.userId, userId)).orderBy(desc(conversations.updatedAt)) : []; }
export async function listImportedConversations(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ conversation: conversations, origin: conversationOrigins })
    .from(conversations)
    .innerJoin(conversationOrigins, eq(conversationOrigins.conversationId, conversations.id))
    .where(and(eq(conversations.userId, userId), eq(conversationOrigins.originType, "manual_file_import")))
    .orderBy(desc(conversations.updatedAt));
}
export async function listMessages(conversationId: number) { const db = await getDb(); return db ? db.select().from(conversationMessages).where(eq(conversationMessages.conversationId, conversationId)).orderBy(conversationMessages.createdAt) : []; }
export async function listMemories(userId: number) { const db = await getDb(); return db ? db.select().from(memories).where(eq(memories.userId, userId)).orderBy(desc(memories.updatedAt)) : []; }
export async function listCouncilRuns(userId: number) { const db = await getDb(); return db ? db.select().from(councilRuns).where(eq(councilRuns.userId, userId)).orderBy(desc(councilRuns.createdAt)) : []; }
export async function getCouncilResults(councilRunId: number) { const db = await getDb(); return db ? db.select().from(councilResults).where(eq(councilResults.councilRunId, councilRunId)).orderBy(councilResults.createdAt) : []; }
export async function listProviderConnections(userId: number) { const db = await getDb(); return db ? db.select().from(providerConnections).where(eq(providerConnections.userId, userId)).orderBy(desc(providerConnections.updatedAt)) : []; }
export async function listHistoryImports(userId: number) { const db = await getDb(); return db ? db.select().from(historyImports).where(eq(historyImports.userId, userId)).orderBy(desc(historyImports.createdAt)) : []; }
export async function listStateSnapshots(userId: number, modelId?: number) {
  const db = await getDb();
  if (!db) return [];
  const condition = modelId ? and(eq(modelStateSnapshots.userId, userId), eq(modelStateSnapshots.modelRegistryId, modelId)) : eq(modelStateSnapshots.userId, userId);
  return db.select().from(modelStateSnapshots).where(condition).orderBy(desc(modelStateSnapshots.createdAt));
}
export async function listStateArtifacts(snapshotId: number) { const db = await getDb(); return db ? db.select().from(modelStateArtifacts).where(eq(modelStateArtifacts.snapshotId, snapshotId)).orderBy(modelStateArtifacts.createdAt) : []; }
export async function listArtifactSources(artifactIds: number[]) { const db = await getDb(); return db && artifactIds.length ? db.select().from(modelStateArtifactSources).where(inArray(modelStateArtifactSources.artifactId, artifactIds)) : []; }
export async function getImportForUser(userId: number, importId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(historyImports).where(and(eq(historyImports.id, importId), eq(historyImports.userId, userId))).limit(1);
  return rows[0];
}
export async function getConnectionForUser(userId: number, connectionId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(providerConnections).where(and(eq(providerConnections.id, connectionId), eq(providerConnections.userId, userId))).limit(1);
  return rows[0];
}
export async function getCurrentSnapshot(userId: number, modelId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(modelStateSnapshots).where(and(eq(modelStateSnapshots.userId, userId), eq(modelStateSnapshots.modelRegistryId, modelId), eq(modelStateSnapshots.isCurrent, true), eq(modelStateSnapshots.status, "published"))).limit(1);
  return rows[0];
}
export async function getOwnedSnapshot(userId: number, snapshotId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(modelStateSnapshots).where(and(eq(modelStateSnapshots.id, snapshotId), eq(modelStateSnapshots.userId, userId))).limit(1);
  return rows[0];
}
export async function ownsConversation(userId: number, conversationId: number) {
  const db = await getDb(); if (!db) return false;
  const rows = await db.select({ id: conversations.id }).from(conversations).where(and(eq(conversations.id, conversationId), eq(conversations.userId, userId))).limit(1);
  return Boolean(rows[0]);
}
export async function ownsModel(userId: number, modelId: number) {
  const db = await getDb(); if (!db) return undefined;
  const rows = await db.select().from(modelRegistry).where(and(eq(modelRegistry.id, modelId), eq(modelRegistry.userId, userId))).limit(1);
  return rows[0];
}
export async function ownsReconstructionRun(userId: number, runId: number) {
  const db = await getDb(); if (!db) return undefined;
  const rows = await db.select().from(reconstructionRuns).where(and(eq(reconstructionRuns.id, runId), eq(reconstructionRuns.userId, userId))).limit(1);
  return rows[0];
}
export async function getContextManifest(manifestId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(councilContextManifests).where(eq(councilContextManifests.id, manifestId)).limit(1);
  return rows[0];
}
export async function getContextItems(manifestId: number) {
  const db = await getDb();
  return db ? db.select().from(councilContextItems).where(eq(councilContextItems.manifestId, manifestId)).orderBy(councilContextItems.ordinal) : [];
}
export async function getOrCreateProviderConnection(userId: number, providerKey: string, displayLabel: string) {
  const db = await getDb();
  if (!db) return undefined;
  const existing = await db.select().from(providerConnections).where(and(eq(providerConnections.userId, userId), eq(providerConnections.providerKey, providerKey))).limit(1);
  if (existing[0]) return existing[0];
  const result = await db.insert(providerConnections).values({ userId, providerKey, displayLabel, status: "active" });
  const row = await db.select().from(providerConnections).where(eq(providerConnections.id, result[0].insertId)).limit(1);
  return row[0];
}

export async function createHistoryImport(userId: number, providerConnectionId: number, sourceFileName: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(historyImports).values({ userId, providerConnectionId, mode: "full", status: "running", sourceFileName, startedAt: new Date() });
  const row = await db.select().from(historyImports).where(eq(historyImports.id, result[0].insertId)).limit(1);
  return row[0];
}

export async function completeHistoryImport(importId: number, counts: { conversationsDiscovered: number; conversationsImported: number; messagesImported: number; duplicatesSkipped: number }, status: "completed" | "partial" | "failed", errorJson?: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(historyImports).set({ ...counts, status, errorJson: errorJson ?? null, completedAt: new Date() }).where(eq(historyImports.id, importId));
}

// Cross-run dedup: has this native conversation already been imported for this
// provider connection? Scoped by providerConnectionId, not historyImportId, so
// re-uploading a refreshed export doesn't create duplicate conversations.
export async function findExistingConversationByNativeId(providerConnectionId: number, nativeConversationId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select({ conversationId: conversationOrigins.conversationId }).from(conversationOrigins).where(and(eq(conversationOrigins.providerConnectionId, providerConnectionId), eq(conversationOrigins.nativeConversationId, nativeConversationId))).limit(1);
  return rows[0]?.conversationId;
}

// Cross-run dedup for messages remains an application-level backup. The
// database uniqueness constraint is now scoped to the stable provider connection
// and native message ID; this query also prevents re-imports for a conversation
// before an insert is attempted.
export async function findExistingMessageNativeIds(conversationId: number): Promise<Set<string>> {
  const db = await getDb();
  if (!db) return new Set();
  const rows = await db
    .select({ nativeMessageId: messageOrigins.nativeMessageId })
    .from(messageOrigins)
    .innerJoin(conversationMessages, eq(messageOrigins.messageId, conversationMessages.id))
    .where(eq(conversationMessages.conversationId, conversationId));
  return new Set(rows.map(r => r.nativeMessageId).filter((id): id is string => id !== null));
}

export async function insertImportedConversation(userId: number, providerConnectionId: number, historyImportId: number, providerKey: string, conv: { nativeConversationId: string; title: string | null; nativeCreatedAt: string; nativeUpdatedAt: string | null; rawPayloadJson: string }) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(conversations).values({ userId, title: conv.title ?? "(untitled import)" });
  const conversationId = result[0].insertId;
  await db.insert(conversationOrigins).values({
    conversationId,
    originType: "manual_file_import",
    providerConnectionId,
    historyImportId,
    providerKey,
    nativeConversationId: conv.nativeConversationId,
    nativeCreatedAt: new Date(conv.nativeCreatedAt),
    nativeUpdatedAt: conv.nativeUpdatedAt ? new Date(conv.nativeUpdatedAt) : null,
    rawPayloadJson: conv.rawPayloadJson,
  });
  return conversationId;
}

// Batch insert. Relies on MySQL's guarantee that auto_increment ids assigned
// within a single multi-row INSERT are contiguous starting at insertId — this
// hasn't been run against a live database, only type-checked, so verify the
// id sequencing on the first real import before trusting it at scale.
export async function insertImportedMessages(conversationId: number, historyImportId: number, providerConnectionId: number, messages: { nativeMessageId: string; nativeParentId: string | null; role: string; content: string; nativeCreatedAt: string; rawPayloadJson: string }[]) {
  const db = await getDb();
  if (!db || messages.length === 0) return 0;
  const role = (r: string): "system" | "user" | "assistant" | "tool" => (r === "user" || r === "assistant" || r === "system" ? r : "tool");
  const result = await db.insert(conversationMessages).values(
    messages.map(m => ({ conversationId, role: role(m.role), content: m.content, createdAt: new Date(m.nativeCreatedAt) })),
  );
  const firstId = result[0].insertId;
  await db.insert(messageOrigins).values(
    messages.map((m, i) => ({
      messageId: firstId + i,
      historyImportId,
      providerConnectionId,
      nativeMessageId: m.nativeMessageId,
      nativeParentId: m.nativeParentId,
      nativeCreatedAt: new Date(m.nativeCreatedAt),
      rawPayloadJson: m.rawPayloadJson,
    })),
  );
  return messages.length;
}

export { conversations, conversationMessages, councilContextItems, councilContextManifests, councilResults, councilRuns, historyImports, memories, messageOrigins, modelRegistry, modelStateArtifactSources, modelStateArtifacts, modelStateSnapshots, providerConnections, reconstructionRuns };
