import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  conversationMessages,
  conversations,
  councilResults,
  councilRuns,
  memories,
  modelRegistry,
  users,
  type InsertUser,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); } catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  }
  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role !== undefined || user.openId === ENV.ownerOpenId) { values.role = user.role ?? "admin"; updateSet.role = values.role; }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listModels(userId: number) { const db = await getDb(); return db ? db.select().from(modelRegistry).where(eq(modelRegistry.userId, userId)).orderBy(desc(modelRegistry.updatedAt)) : []; }
export async function listConversations(userId: number) { const db = await getDb(); return db ? db.select().from(conversations).where(eq(conversations.userId, userId)).orderBy(desc(conversations.updatedAt)) : []; }
export async function listMessages(conversationId: number) { const db = await getDb(); return db ? db.select().from(conversationMessages).where(eq(conversationMessages.conversationId, conversationId)).orderBy(conversationMessages.createdAt) : []; }
export async function listMemories(userId: number) { const db = await getDb(); return db ? db.select().from(memories).where(eq(memories.userId, userId)).orderBy(desc(memories.updatedAt)) : []; }
export async function listCouncilRuns(userId: number) { const db = await getDb(); return db ? db.select().from(councilRuns).where(eq(councilRuns.userId, userId)).orderBy(desc(councilRuns.createdAt)) : []; }
export async function getCouncilResults(councilRunId: number) { const db = await getDb(); return db ? db.select().from(councilResults).where(eq(councilResults.councilRunId, councilRunId)).orderBy(councilResults.createdAt) : []; }

export async function ownsConversation(userId: number, conversationId: number) {
  const db = await getDb(); if (!db) return false;
  const rows = await db.select({ id: conversations.id }).from(conversations).where(and(eq(conversations.id, conversationId), eq(conversations.userId, userId))).limit(1);
  return Boolean(rows[0]);
}

export async function ownsModel(userId: number, modelId: number) {
  const db = await getDb(); if (!db) return undefined;
  const rows = await db.select().from(modelRegistry).where(and(eq(modelRegistry.id, modelId), eq(modelRegistry.userId, userId))).limit(1);
  return rows[0];
}
