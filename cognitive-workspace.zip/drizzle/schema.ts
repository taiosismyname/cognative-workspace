import {
  bigint,
  boolean,
  index,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const modelRegistry = mysqlTable(
  "model_registry",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    providerKey: varchar("providerKey", { length: 64 }).notNull(),
    modelKey: varchar("modelKey", { length: 255 }).notNull(),
    displayName: varchar("displayName", { length: 255 }).notNull(),
    adapterStatus: mysqlEnum("adapterStatus", ["active", "unimplemented", "disabled"]).notNull().default("active"),
    capabilities: json("capabilities"),
    notes: text("notes"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({ ownerIdx: index("model_registry_user_idx").on(table.userId) }),
);

export const conversations = mysqlTable(
  "conversations",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    title: varchar("title", { length: 255 }).notNull(),
    summary: text("summary"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({ ownerIdx: index("conversations_user_idx").on(table.userId) }),
);

export const conversationMessages = mysqlTable(
  "conversation_messages",
  {
    id: int("id").autoincrement().primaryKey(),
    conversationId: int("conversationId").notNull(),
    role: mysqlEnum("role", ["system", "user", "assistant", "tool"]).notNull(),
    content: text("content").notNull(),
    modelRegistryId: int("modelRegistryId"),
    providerRequestId: varchar("providerRequestId", { length: 255 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({ conversationIdx: index("conversation_messages_conversation_idx").on(table.conversationId) }),
);

export const memories = mysqlTable(
  "memories",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    modelRegistryId: int("modelRegistryId").notNull(),
    sourceConversationId: int("sourceConversationId").notNull(),
    sourceMessageId: int("sourceMessageId").notNull(),
    content: text("content").notNull(),
    memoryType: varchar("memoryType", { length: 64 }).notNull().default("fact"),
    embeddingJson: text("embeddingJson"),
    embeddingModel: varchar("embeddingModel", { length: 255 }),
    isRetrievalEligible: boolean("isRetrievalEligible").notNull().default(true),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    ownerIdx: index("memories_user_idx").on(table.userId),
    modelIdx: index("memories_model_idx").on(table.modelRegistryId),
    provenanceIdx: index("memories_provenance_idx").on(table.sourceConversationId, table.sourceMessageId),
  }),
);

export const councilRuns = mysqlTable(
  "council_runs",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    prompt: text("prompt").notNull(),
    status: mysqlEnum("status", ["running", "completed", "partial", "failed"]).notNull().default("running"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    completedAt: timestamp("completedAt"),
  },
  table => ({ ownerIdx: index("council_runs_user_idx").on(table.userId) }),
);

export const councilResults = mysqlTable(
  "council_results",
  {
    id: int("id").autoincrement().primaryKey(),
    councilRunId: int("councilRunId").notNull(),
    modelRegistryId: int("modelRegistryId").notNull(),
    status: mysqlEnum("status", ["running", "completed", "failed"]).notNull().default("running"),
    responseText: text("responseText"),
    rawProviderPayload: text("rawProviderPayload"),
    normalizedResult: text("normalizedResult"),
    errorMessage: text("errorMessage"),
    providerRequestId: varchar("providerRequestId", { length: 255 }),
    latencyMs: bigint("latencyMs", { mode: "number" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    completedAt: timestamp("completedAt"),
  },
  table => ({ runIdx: index("council_results_run_idx").on(table.councilRunId) }),
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type ModelRegistry = typeof modelRegistry.$inferSelect;
export type Conversation = typeof conversations.$inferSelect;
export type ConversationMessage = typeof conversationMessages.$inferSelect;
export type Memory = typeof memories.$inferSelect;
export type CouncilRun = typeof councilRuns.$inferSelect;
export type CouncilResult = typeof councilResults.$inferSelect;
