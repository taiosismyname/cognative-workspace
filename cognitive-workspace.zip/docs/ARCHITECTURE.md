# Cognitive Workspace Architecture

Cognitive Workspace is a provider-independent workspace for preserving source conversations, deriving model-specific memories, retrieving those memories semantically, and routing prompts through recorded multi-model councils.

## Adapter boundary

The server owns a small `ModelProviderAdapter` contract in `server/adapters.ts`. Each adapter exposes `listModels`, `complete`, and `embed`; the workspace stores only the provider key and model key in its registry. The OpenRouter adapter is implemented with live requests to the OpenRouter API. Providers without an adapter are represented with `adapterStatus: unimplemented` and fail explicitly before any provider call. No mock response path exists.

## Source and derived data

`conversations` and `conversation_messages` are the source archive. They are never used as a memory table and remain independently reviewable. `memories` is a derived ledger. Every memory requires `modelRegistryId`, `sourceConversationId`, and `sourceMessageId`; the API verifies that the source conversation belongs to the authenticated user and that the source message belongs to that conversation before insertion.

> A memory without a source conversation and source message is invalid by design.

The `embeddingJson` and `embeddingModel` fields belong to the derived memory record. If the embedding provider is unavailable, the memory may still be stored as non-embedded, but semantic retrieval reports that it is unavailable rather than using a lexical or fabricated fallback.

## Retrieval

Semantic retrieval embeds the query with the OpenRouter embedding endpoint, compares it with eligible stored vectors using cosine similarity, and returns the memory together with its model, conversation title, source conversation ID, source message ID, and source message timestamp. Retrieval eligibility is explicit through `isRetrievalEligible`.

## Councils

A council creates one durable run and one durable result row per selected registered model. Calls execute through the model's adapter. Each result records `completed`, `failed`, provider request ID, latency, response text, or an error message. A council can therefore be `completed`, `partial`, or `failed` without discarding successful sibling results.

## Configuration

The application expects the platform-provided database and authentication variables plus `OPENROUTER_API_KEY`. The embedding model defaults to `openai/text-embedding-3-small` and can be changed through `OPENROUTER_EMBEDDING_MODEL`. Secrets are server-side only and must not be committed to the repository.

## GitHub source repository

The project is structured as a conventional Git repository with source under `client/`, `server/`, `drizzle/`, `shared/`, and `docs/`. Use the project Management UI's GitHub panel to export this project to a GitHub repository after authentication. Keep the repository private if conversation content or memory records will be used during development.

## Unsupported integrations

Direct Anthropic and direct Google adapters are intentionally represented as unimplemented boundaries in `server/adapters.ts`. OpenRouter can still route to models exposed by those vendors when the model is available through OpenRouter; that does not imply a direct vendor integration. The UI and API preserve the distinction.
