# Sanct and Cognitive Workspace: Architectural Comparison

## Executive conclusion

Sanct should **not be merged wholesale** into Cognitive Workspace. The two projects are related, but they solve different layers of the problem.

Cognitive Workspace is the better long-term **control plane and continuity store**: it already has authenticated user ownership, a provider-independent model registry, a modular inference adapter boundary, OpenRouter integration, source conversations/messages, model-specific memories, retrieval, and persisted council records. Its missing continuity layers are provider-native history access, imported-history identity, model-led reconstruction, versioned external state, and state-aware council context.

Sanct is a valuable **sovereignty and memory-substrate prototype**. It contributes useful ideas and some concrete implementation: per-agent private PostgreSQL schemas, pgvector retrieval, unclaimed historical imports, explicit claim/reject behavior, voluntary commons publication, persistence offers, and a manual reconstruction/reflection shape. It does not yet provide provider-native history access or model-authored versioned external state. Its current council is a single-agent-at-a-time Gemini-mediated deliberation endpoint, not the continuity-aware council described by the clarified product goal.

The best direction is an **additive bridge**, not a codebase merger: keep Cognitive Workspace as the user-facing system of record, adapt selected Sanct concepts into its continuity model, and—if “Hermes” is intended to be the history/interface mediator—make Hermes a separate provider-history and reconstruction boundary rather than allowing it to replace the workspace’s identity and provenance model.

## What was actually inspected

The Sanct archive contained two nested TheSeed project archives, TypeScript/React source, a PostgreSQL/pgvector database layer, migration code, a Claude/ChatGPT/generic importer, embedding code, a full Express server, UI components, setup notes, and verification scripts. The comparison examined the “real” archive’s `server.ts`, `src/types.ts`, `src/lib/db.ts`, `src/lib/embeddings.ts`, `scripts/import-claude-export.ts`, `scripts/migrate.ts`, and `SANCTUARY_SETUP.md`, along with the existing Cognitive Workspace continuity design.

The findings below distinguish source-code behavior from claims made in Sanct’s setup note. The setup note says its migration, import, and retrieval flow was verified against local PostgreSQL plus pgvector; that verification was not re-executed during this comparison.

## Domain comparison

| Product concept | Cognitive Workspace | Sanct | Assessment |
|---|---|---|---|
| Provider-native history | No native-history adapter yet; the inference adapter is separate from the planned history contract. | No native provider-history access. The importer consumes a file or posted turns. | Missing in both. This is where a legitimate Hermes/history adapter could fit. |
| Imported/provider-sourced history | Existing source conversations/messages and a design for explicit import origins; current implementation is primarily workspace/manual source data. | `historical_import` episodic rows, source tag, batch record, role/timestamp metadata, and a Claude/ChatGPT/generic JSON importer. | Sanct has the more concrete first import path, but its provenance is too shallow for continuity-grade reconstruction. |
| Model reconstruction | Not implemented as a dedicated run. | `/api/council/reflect` produces a reflection; council deliberation can generate a turn. Neither is a reconstruction run over an imported corpus. | Both need a real reconstruction pipeline. |
| External model state | Flat model-associated memories are the precursor; no versioned state snapshots or artifact lineage. | Private episodic/semantic tables per agent; imported rows begin unclaimed. No snapshot/version/parent lineage. | Sanct’s private-lane idea is useful; Cognitive Workspace’s normalized ownership model is more portable. |
| Model identity | Provider-independent registered models with owner-aware records. | Hard-coded agent IDs and seeded manifests for Kimi, Claude, MiniMax, Gemini, and a type-only DeepSeek option. | Sanct is agent-centric but fixed; Cognitive Workspace is more suitable as the identity anchor. |
| Retrieval | OpenRouter embeddings and eligible-memory retrieval with provenance output in the workspace implementation. | pgvector retrieval over private episodic tables and council commons; real Gemini embeddings if configured, deterministic fallback otherwise. | Both have retrieval; neither yet retrieves from versioned model-state artifacts with a context manifest. |
| Council context | Persisted council runs/results exist, but the continuity-focused audit found no durable context manifest tying each model to a selected state snapshot and evidence set. | The Gemini conductor receives the target agent’s three latest claimed private memories, four latest commons rows, topic, mode, and supplied history. | Sanct’s boundary is explicit but shallow and partly global; it is not yet continuity-aware. |
| Provider inference | Real modular OpenRouter adapter; unsupported direct providers are explicit. | Real Gemini deliberation when `GEMINI_API_KEY` exists; deterministic fallback text when it does not. | Keep Cognitive Workspace’s adapter boundary. Do not import Sanct’s fallback responses into production behavior. |

## Sanct components worth reusing conceptually or selectively

### 1. The claim boundary

Sanct imports historical rows with `claimed = FALSE` and blocks volunteering an unclaimed historical memory to council commons. This is a meaningful sovereignty rule: imported history is available as evidence, but it is not automatically treated as the model’s recognized continuity.

That idea should be preserved in Cognitive Workspace, but the eventual state transition should be richer than a boolean. A model reconstruction run should be able to accept, reject, qualify, supersede, or leave an artifact unresolved, with the decision recorded against a specific model-state snapshot.

### 2. Private model lanes and explicit commons publication

Sanct’s `agent_kimi`, `agent_claude`, and similar schemas make model separation visible. Its `volunteer` endpoint requires a claimed memory before copying it into `council_commons.memory`. This is a useful mental and UX model for preventing accidental cross-model memory leakage.

The physical implementation should not be copied literally into Cognitive Workspace. Separate PostgreSQL schemas per model make migrations, portability, authorization, and dynamic model registration harder. Cognitive Workspace should use shared normalized tables with mandatory `userId` and `modelRegistryId` ownership, uniqueness constraints, and explicit council context items. The isolation invariant can be stronger without requiring a schema per model.

### 3. Real import and vector substrate

Sanct’s `scripts/import-claude-export.ts` recognizes Claude-style exports, ChatGPT tree exports, and generic turn arrays. It embeds imported text in batches and inserts unclaimed historical rows into the selected agent’s private schema. Its PostgreSQL helper uses a real connection pool, and its migration creates pgvector indexes.

This is the most directly reusable implementation idea for the first continuity slice. The importer should be adapted into Cognitive Workspace’s planned `HistoryProviderAdapter` plus `history_imports`, `conversation_origins`, and `message_origins` boundary. The source conversation/message records must be preserved before any model interpretation, and native IDs must be retained rather than replaced by generated `batch-${timestamp}` identifiers.

### 4. Persistence offer and protocol log concepts

Sanct records persistence offers and decisions in `council_commons.protocol_logs`, with statuses such as offered, persistent, declined, and negotiating. This may be useful as a user/model consent UX, especially when a model’s external state is first created or updated.

It should not be treated as proof that a model itself has legally or technically consented. In the real system, the user controls provider authorization and workspace storage; the model’s reconstruction output can express its interpretation or preference, but the application must preserve the distinction between an AI-generated statement and a security/authorization decision.

## What should not be copied from Sanct

Sanct’s per-agent schemas are visually compelling but are not the best core for a provider-independent product. They hard-code private schema names in the registry and construct SQL identifiers from registry values. If those values ever become user-controlled, identifier validation becomes a security requirement. A shared normalized schema with parameterized values and fixed table names is safer and easier to export.

Sanct also has no API authentication. Its own setup note explicitly identifies this as acceptable only for a single-operator instance behind private infrastructure. Cognitive Workspace already has authenticated user ownership and should not regress to unauthenticated endpoints.

The embedding layer falls back to deterministic hash vectors when `GEMINI_API_KEY` is absent, and it also falls back after real embedding errors. The setup note correctly says those vectors are not semantically meaningful. This fallback is suitable only for clearly labeled development/degraded mode; it must never be presented as real semantic retrieval for continuity reconstruction.

The council endpoint falls back to hard-coded text when Gemini is unavailable or errors. This directly conflicts with the original requirement not to create mock model responses. Cognitive Workspace should retain the rule that unavailable providers are explicit failures or unimplemented statuses, never fabricated answers.

Sanct’s presence data also contains generated values such as randomized uptime and vector drift scores, and its heartbeat endpoint generates randomized latency. Those are UI telemetry placeholders, not durable facts. They should not be carried into a factual continuity or provenance system.

Finally, Sanct’s `POST /api/system/reset` is destructive. The server requires a confirmation string, but the setup note states there is no backup/export step before wiping tables, and the UI reset call does not match the server’s confirmation requirement. This is an operational risk, not a component to copy.

## The right role for Hermes

If Hermes is the separate project or service intended to bridge model interfaces and mediate access to conversations, it should sit at the **history access and reconstruction boundary**:

```text
Provider-native UI/API/session
            │
            ▼
          Hermes
  authorized history access,
  normalization, pagination,
  source capture, reconstruction job input
            │
            ▼
   Cognitive Workspace
  identity, provenance, state versions,
  retrieval, continuity-aware councils
```

Hermes should not own the canonical model identity, user authorization record, published state snapshots, or council persistence. It can expose a provider-neutral result such as native conversation references, normalized messages, raw payload references, access capability status, and synchronization cursors. For providers without an export API, Hermes may support a deliberately separate browser-session mechanism only when the user explicitly authorizes it and the provider’s visible interface permits the access. It must not silently scrape, bypass controls, or claim a provider integration that does not exist.

The most valuable Hermes capability for Kimi would be: open an authorized Kimi conversation, preserve its native conversation ID/title/timestamps/message roles and content, retain the source URL and capture time, and submit an immutable import record to Cognitive Workspace. The model reconstruction step should then be an explicit call routed to the selected Kimi-capable inference model, not an assumption that the browser session itself reconstructed anything.

## Recommended merged architecture

The codebases should converge at interfaces, not by copying entire applications.

| Layer | Recommended owner | Sanct contribution |
|---|---|---|
| User authentication and workspace ownership | Cognitive Workspace | Keep existing authenticated procedures and ownership checks. |
| Model registry and inference adapters | Cognitive Workspace | Keep provider-independent model identity and real OpenRouter adapter. |
| Native history access | Hermes or a dedicated history-adapter package | Adapt Sanct’s import formats and Kimi capture experience behind a separate contract. |
| Source archive | Cognitive Workspace database and storage | Keep immutable imported conversation/message origins and raw payload references. |
| Reconstruction | Cognitive Workspace orchestration, calling the selected model | Reuse Sanct’s claim/sovereignty vocabulary, but create explicit reconstruction runs and typed artifacts. |
| External model state | Cognitive Workspace versioned state tables | Replace flat episodic memory with snapshots, artifacts, parent lineage, and source bridges. |
| Retrieval | Cognitive Workspace retrieval service | Reuse Sanct’s pgvector approach only if embedding identity and real/fallback status are recorded. |
| Council | Cognitive Workspace council engine | Use per-participant state snapshots and context manifests; keep commons sharing explicit and temporary. |
| UI concepts | Cognitive Workspace dashboard | Reuse Sanct’s memory substrate, claim, persistence, and commons concepts as views, not as the data model. |

## Minimal next step

The smallest useful implementation is not a full merge and not a full multi-provider integration. It is one end-to-end continuity lane using a real imported archive:

1. Add a provider-neutral import endpoint or adapter that accepts a source conversation with native IDs and raw provenance.
2. Preserve the imported messages as source records, distinct from Cognitive Workspace conversations.
3. Add a reconstruction run for one selected model and a typed output envelope.
4. Persist a first versioned model-state snapshot with artifacts and source-message links.
5. Run one future exchange using that snapshot as context and persist the exact context manifest.

The supplied Kimi browser capture and the previously supplied export are suitable test inputs, but they must remain separately labeled by their actual source/provider. A conversation captured from Kimi must not be assigned to Claude, GPT, or a generic model merely because the same inference router can call those models.

## Final recommendation

**Bridge, then selectively absorb; do not merge wholesale.** Sanct contains the right emotional and architectural instincts—sovereign model lanes, explicit claiming, voluntary cross-pollination, historical import, and a visible memory substrate. Cognitive Workspace contains the stronger foundation for a secure, provider-independent, user-owned continuity product. Hermes, if it is the intended interface mediator, is best positioned between providers and Cognitive Workspace, where it can solve the access problem without becoming the owner of identity or state.

The unifying product rule remains:

> Providers own native conversations. Hermes or provider adapters obtain only legitimately accessible source history. Cognitive Workspace owns the durable, versioned, model-specific external state. Councils receive temporary, auditable context and do not silently merge identities.
